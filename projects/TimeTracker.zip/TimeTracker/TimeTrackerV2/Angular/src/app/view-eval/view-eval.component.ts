import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-eval',
  templateUrl: './view-eval.component.html',
  styleUrls: ['./view-eval.component.css']
})
export class ViewEvalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  public pageTitle = 'TimeTrackerV2 | View Eval'

}
