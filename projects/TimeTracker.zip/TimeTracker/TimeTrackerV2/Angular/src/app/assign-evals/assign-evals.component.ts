import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assign-evals',
  templateUrl: './assign-evals.component.html',
  styleUrls: ['./assign-evals.component.css']
})

export class AssignEvalsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  public pageTitle = 'TimeTrackerV2 | Assign Evals'

}
